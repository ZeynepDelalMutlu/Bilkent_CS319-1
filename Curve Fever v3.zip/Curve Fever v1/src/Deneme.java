import javax.swing.*;
import java.awt.*;

// This example is for the CollisionDetector. It gives the color of a specific pixel given the coordinates.
public class Deneme extends JFrame
{
    public Deneme ()
    {
        setSize(1000, 600); // STATIC
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public void paint ()
    {
        Graphics g = getGraphics();

        g.setColor(Color.red);
        g.fillOval(500,300,50,50);
    }

    public static void main(String[] args)
    {
        Deneme d = new Deneme();

        while (true)
        {
            d.paint();
        }
    }
}


// ----------------------------------------------------------

//import java.awt.event.KeyEvent;
//import java.util.Scanner;

// This example shows how to store key configurations. They simply will be stored in an int.
//public class Deneme
//{
//    public static void main(String[] args)
//    {
//        int keyConfiguration;
//        Scanner scan = new Scanner(System.in);

//        String input = scan.next();

//        if (input.equals("a"))
//        {
//            keyConfiguration = KeyEvent.VK_A;
//            System.out.println(keyConfiguration);
//        }
//    }
//}